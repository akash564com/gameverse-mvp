games = [
    {
        "name": "Tetris",
        "slug": "tetris",
        "description": "Classic block-stacking puzzle game.",
        "image": "https://via.placeholder.com/200x120.png?text=Tetris"
    },
    {
        "name": "Pong",
        "slug": "pong",
        "description": "The original arcade tennis game.",
        "image": "https://via.placeholder.com/200x120.png?text=Pong"
    }
]
